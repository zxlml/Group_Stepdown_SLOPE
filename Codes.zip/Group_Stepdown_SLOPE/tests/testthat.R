library(testthat)
library(grpSLOPE)

test_check("grpSLOPE")

