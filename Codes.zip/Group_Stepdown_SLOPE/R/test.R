###############################################################################
#
#    2025 08 17  xuelin zhang
#
###############################################################################

library(grpSLOPE)

path = "your path"
setwd(path)
source('grpSLOPE.R')
times <- 5
gamma <- 0.1
# kk <- c(5,10,15,20,25)
# relevant_number <- c(50,100,150,200,250)

kk <- c(10)
relevant_number <- c(30)

#Three modes for our gSLOPE,kGSLOPE,FGSLOPE

gFDP_g <- matrix(0,length(relevant_number),length(kk))
gkFWER_g<- matrix(0,length(relevant_number),length(kk))
gFDR_mean_g <- matrix(0,length(relevant_number),length(kk))
Power_mean_g <-matrix(0,length(relevant_number),length(kk))

gFDP_kg <- matrix(0,length(relevant_number),length(kk))
gkFWER_kg<- matrix(0,length(relevant_number),length(kk))
gFDR_mean_kg <- matrix(0,length(relevant_number),length(kk))
Power_mean_kg <-matrix(0,length(relevant_number),length(kk))


gFDP_Fg <- matrix(0,length(relevant_number),length(kk))
gkFWER_Fg<- matrix(0,length(relevant_number),length(kk))
gFDR_mean_Fg <- matrix(0,length(relevant_number),length(kk))
Power_mean_Fg <-matrix(0,length(relevant_number),length(kk))


for (u in 1:length(relevant_number))
{
  gFDR_g <- matrix(0,length(kk),times)
  Power_g <- matrix(0,length(kk),times)
  gFDR_kg <- matrix(0,length(kk),times)
  Power_kg <- matrix(0,length(kk),times)
  gFDR_Fg <- matrix(0,length(kk),times)
  Power_Fg <- matrix(0,length(kk),times)
  
  Vg_g <- matrix(0,length(kk),times)
  Rg_g <- matrix(0,length(kk),times)
  Vg_kg <- matrix(0,length(kk),times)
  Rg_kg <- matrix(0,length(kk),times)
  Vg_Fg <- matrix(0,length(kk),times)
  Rg_Fg <- matrix(0,length(kk),times)
  
  for (t in 1:length(kk))
  {
    jj_g <- 0 
    ff_g <- 0
    jj_kg <- 0 
    ff_kg <- 0
    jj_Fg <- 0 
    ff_Fg <- 0
    print(paste('第',u,'大循环第',t,'小循环'))
    
    for(i in 1:times)
    {
      p     <- 4000 #行
      # n <- sum(rbinom(1000,1000,0.008)) #列
      X <- scale(matrix(rnorm(p*p,mean=0,sd=1/p),p,p))
      #group <- c(rep(1:(p/5),each=5))#组内相同
      # 组内不同
      # group <- c(rep(1:200, each=3),
      #            rep(201:400, each=4),
      #            rep(401:600, each=5),
      #            rep(601:800, each=6),
      #            rep(801:1000, each=7))
      
      group <- c(rep(1:160, each=3),
                 rep(161:320, each=4),
                 rep(321:480, each=5),
                 rep(481:640, each=6),
                 rep(641:800, each=7))

      group <- paste0("grp", group)
      print(paste('重复实验',i,'次'))
      # this generates a list containing a vector of indices for each group:
      group.id <- grpSLOPE::getGroupID(group)
      # this extracts the total number of groups:
      n.group <- length(group.id)
      # this vector collects the sizes of every group of predictors:
      group.length <- sapply(group.id, FUN=length)
      # this vector collects the group names:
      group.names <- names(group.id)
      
      ind.relevant <- sort(sample(1:n.group, relevant_number)) 
      relevant_groups <-paste0("grp",ind.relevant)
      
      l = rep(qr(X)$rank,n.group)#矩阵的秩
      B = sqrt((4*log(n.group))/(1-n.group^{-2/l})-l)
      a = B / sum(sqrt(l))
      
      b <- rep(0, p)
      for (j in ind.relevant) {
        b[group.id[[j]]] <- runif(group.length[j])/(a[j]*sqrt(l[j]))
      }
      y <- X %*% b + rnorm(p)
      
      #GSLOPE
      # model_g <- grpSLOPE(X=X, y=y, group=group,k = kk[t],fdr=0.1,lambda='corrected')
      #k-GSLOPE
      # model_kg <- grpSLOPE(X=X, y=y, group=group,k = kk[t],fdr=0.1,lambda='corrected-kfwer')
      #F-GSLOPE
      model_Fg <- grpSLOPE(X=X, y=y, group=group,k = kk[t],gamma = gamma,fdr=0.1,lambda='correct-fdp')
      
      # 三次模型的model$selected
      
      # Rg_g[t,i] <- length(model_g$selected)
      # Vg_g[t,i] <- length(setdiff(model_g$selected,relevant_groups))
      # Rg_kg[t,i] <- length(model_kg$selected)
      # Vg_kg[t,i] <- length(setdiff(model_kg$selected,relevant_groups))
      Rg_Fg[t,i] <- length(model_Fg$selected)
      Vg_Fg[t,i] <- length(setdiff(model_Fg$selected,relevant_groups))
      
      # gFDR_g[t,i] <- Vg_g[t,i]/max(1,Rg_g[t,i])
      # Power_g[t,i] <- (Rg_g[t,i]-Vg_g[t,i])/length(relevant_groups)
      # gFDR_kg[t,i] <- Vg_kg[t,i]/max(1,Rg_kg[t,i])
      # Power_kg[t,i] <- (Rg_kg[t,i]-Vg_kg[t,i])/length(relevant_groups)
      gFDR_Fg[t,i] <- Vg_Fg[t,i]/max(1,Rg_Fg[t,i])
      Power_Fg[t,i] <- (Rg_Fg[t,i]-Vg_Fg[t,i])/length(relevant_groups)
      
      # if (Vg_g[t,i] > kk[t])
      # {
      #   jj_g <- jj_g + 1
      # }
      # if (Vg_kg[t,i] > kk[t])
      # {
      #   jj_kg <- jj_kg + 1
      # }
      if (Vg_Fg[t,i] > kk[t])
      {
        jj_Fg <- jj_Fg + 1
      }

      
      # if (gFDR_g[t,i] > gamma)
      # {
      #   ff_g <- ff_g + 1
      # }
      # if (gFDR_kg[t,i] > gamma)
      # {
      #   ff_kg <- ff_kg + 1
      # }
      if (gFDR_Fg[t,i] > gamma)
      {
        ff_Fg <- ff_Fg + 1
      }

    }
    
    # gFDP_g[u,t]<-ff_g/times
    # gkFWER_g[u,t]<-jj_g/times
    # gFDR_mean_g[u,t] <- mean(gFDR_g[t,])
    # Power_mean_g[u,t] <- mean(Power_g[t,])
    # 
    # gFDP_kg[u,t]<-ff_kg/times
    # gkFWER_kg[u,t]<-jj_kg/times
    # gFDR_mean_kg[u,t] <- mean(gFDR_kg[t,])
    # Power_mean_kg[u,t] <- mean(Power_kg[t,])
    
    gFDP_Fg[u,t]<-ff_Fg/times
    gkFWER_Fg[u,t]<-jj_Fg/times
    gFDR_mean_Fg[u,t] <- mean(gFDR_Fg[t,])
    Power_mean_Fg[u,t] <- mean(Power_Fg[t,])
  }
}



